import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, User, Phone, Mail, FileText, Trash2, ShieldCheck, MapPin, Briefcase } from 'lucide-react';
import { Booking, ContactInquiry, Designer } from '../types';

interface SolicitudesPanelProps {
  isOpen: boolean;
  onClose: () => void;
  bookings: Booking[];
  inquiries: ContactInquiry[];
  designers: Designer[];
  onDeleteBooking: (id: string) => void;
  onDeleteInquiry: (id: string) => void;
}

export default function SolicitudesPanel({
  isOpen,
  onClose,
  bookings,
  inquiries,
  designers,
  onDeleteBooking,
  onDeleteInquiry
}: SolicitudesPanelProps) {

  const getDesignerName = (id: string) => {
    return designers.find(d => d.id === id)?.name || 'Especialista General';
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
          />

          {/* Slider Container */}
          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="w-screen max-w-md"
            >
              <div className="h-full flex flex-col bg-white shadow-2xl border-l border-outline-variant">
                {/* Header */}
                <div className="p-6 bg-surface border-b border-outline-variant flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="text-primary" size={20} />
                    <h3 className="font-display text-headline-sm text-on-surface">Panel de Solicitudes</h3>
                  </div>
                  <button
                    onClick={onClose}
                    className="p-1 hover:text-primary text-outline transition-colors"
                  >
                    <X size={24} />
                  </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                  {/* Citas Agendadas */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-outline-variant pb-2">
                      <h4 className="font-display font-semibold text-sm text-primary uppercase tracking-wider">Citas de Asesoría ({bookings.length})</h4>
                      <span className="font-mono text-[10px] text-on-surface-variant bg-pearl-grey px-2 py-0.5 uppercase">Local Storage</span>
                    </div>

                    {bookings.length === 0 ? (
                      <p className="text-xs text-on-surface-variant italic py-2">No hay citas agendadas aún. Agende una desde la barra de navegación.</p>
                    ) : (
                      <div className="space-y-3">
                        {bookings.map((b) => (
                          <div key={b.id} className="p-4 bg-background border border-outline-variant rounded-none relative group space-y-2">
                            <button
                              onClick={() => onDeleteBooking(b.id)}
                              className="absolute top-3 right-3 text-on-surface-variant hover:text-error opacity-0 group-hover:opacity-100 transition-opacity p-1"
                              title="Eliminar cita"
                            >
                              <Trash2 size={14} />
                            </button>

                            <div className="flex items-center space-x-2">
                              <Calendar size={14} className="text-primary" />
                              <span className="text-xs font-semibold text-on-surface">{b.date} a las {b.time}</span>
                            </div>

                            <div className="space-y-1 text-xs text-on-surface-variant">
                              <div className="flex items-center space-x-2">
                                <User size={12} />
                                <span className="font-medium text-on-surface">{b.name}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Mail size={12} />
                                <span>{b.email}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Phone size={12} />
                                <span>{b.phone}</span>
                              </div>
                              <div className="flex items-center space-x-2 pt-1">
                                <Briefcase size={12} className="text-secondary" />
                                <span className="text-secondary font-medium">{b.projectType} — {getDesignerName(b.designerId)}</span>
                              </div>
                            </div>

                            {b.notes && (
                              <div className="text-[11px] bg-white p-2 border-l border-primary/30 text-on-surface-variant">
                                <strong>Nota:</strong> {b.notes}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Consultas del Formulario */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-outline-variant pb-2">
                      <h4 className="font-display font-semibold text-sm text-primary uppercase tracking-wider">Mensajes de Contacto ({inquiries.length})</h4>
                    </div>

                    {inquiries.length === 0 ? (
                      <p className="text-xs text-on-surface-variant italic py-2">No hay mensajes recibidos aún. Use el formulario de la sección Contacto.</p>
                    ) : (
                      <div className="space-y-3">
                        {inquiries.map((inq) => (
                          <div key={inq.id} className="p-4 bg-background border border-outline-variant rounded-none relative group space-y-2">
                            <button
                              onClick={() => onDeleteInquiry(inq.id)}
                              className="absolute top-3 right-3 text-on-surface-variant hover:text-error opacity-0 group-hover:opacity-100 transition-opacity p-1"
                              title="Eliminar consulta"
                            >
                              <Trash2 size={14} />
                            </button>

                            <div className="flex justify-between items-center">
                              <span className="text-[10px] text-outline">{inq.date}</span>
                              <span className="text-[10px] font-semibold text-secondary uppercase bg-secondary-container/15 px-2 py-0.5">{inq.projectType}</span>
                            </div>

                            <div className="space-y-1 text-xs text-on-surface-variant">
                              <div className="flex items-center space-x-2">
                                <User size={12} className="text-primary" />
                                <span className="font-medium text-on-surface">{inq.name}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Phone size={12} />
                                <span>{inq.phone}</span>
                              </div>
                              {inq.location && (
                                <div className="flex items-center space-x-2">
                                  <MapPin size={12} />
                                  <span>{inq.location}</span>
                                </div>
                              )}
                            </div>

                            {inq.message && (
                              <div className="text-xs bg-white p-2 border border-outline-variant rounded-none text-on-surface-variant">
                                <FileText size={10} className="inline mr-1 text-primary" />
                                {inq.message}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer */}
                <div className="p-4 bg-surface border-t border-outline-variant text-center text-[10px] text-on-surface-variant">
                  K° STUDIO | Sistema de Gestión Local (Folleto Interactivo)
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
