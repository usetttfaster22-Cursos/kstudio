import React from 'react';
import { ExternalLink } from 'lucide-react';
import Logo from './Logo';

export default function Footer() {
  const brands = ['LUMINAR', 'ERCO', 'FLOS', 'DELTA LIGHT', 'IGUZZINI'];

  return (
    <footer className="bg-pearl-grey border-t border-outline-variant/60">
      {/* Brands & Alliances Banner */}
      <div className="py-16 border-b border-outline-variant/45 bg-surface-bright">
        <div className="max-w-[1280px] mx-auto px-6 sm:px-12 overflow-hidden space-y-10">
          <p className="text-center font-sans text-xs uppercase tracking-widest font-bold text-on-surface-variant">
            Marcas que representamos y aliados estratégicos
          </p>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-24 opacity-50 hover:opacity-80 grayscale hover:grayscale-0 transition-all duration-500">
            {brands.map((brand) => (
              <div
                key={brand}
                className="font-display text-base sm:text-lg font-bold tracking-widest text-on-surface"
              >
                {brand}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer Section */}
      <div className="flex flex-col md:flex-row justify-between items-center px-6 sm:px-12 py-16 max-w-[1280px] mx-auto w-full gap-8">
        <div className="text-center md:text-left space-y-4">
          <Logo variant="navbar" height={42} />
          <p className="font-sans text-xs text-on-surface-variant">
            © {new Date().getFullYear()} K° STUDIO. Neuroiluminación y Arquitectura.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-8 items-center">
          <a
            href="#"
            className="font-sans text-xs uppercase tracking-widest font-semibold text-on-surface-variant hover:text-primary transition-colors"
          >
            Privacidad
          </a>
          <a
            href="#"
            className="font-sans text-xs uppercase tracking-widest font-semibold text-on-surface-variant hover:text-primary transition-colors"
          >
            Términos
          </a>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="font-sans text-xs uppercase tracking-widest font-semibold text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1.5"
          >
            Instagram
            <ExternalLink size={12} />
          </a>
        </div>
      </div>
    </footer>
  );
}
